#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

#define VISITADO 1
#define NAOVISITADO 0

typedef pair<int, int> ii; // vertice v e peso
typedef vector<ii> vii;
typedef vector<int> vi;

vector<vii> AdjList(200);

int V;
int A;

vi visitado;


void printAdjList(int V){
	for (int u = 0; u < V; ++u) { // para todos os vertices...
		printf("%d: ", u+1);
		// para todo v adj a u
		for (int i = 0; i < AdjList[u].size(); ++i){
			ii v = AdjList[u][i];
			printf("(%d,%d) -> ", v.first+1, v.second);
		}
		printf("\n");
	}
}


void dfs(int u){
	printf("%d ", u+1);
	visitado[u] = VISITADO;

	// para todo v adj a u
		for (int i = 0; i < AdjList[u].size(); ++i){
			ii v = AdjList[u][i];
			if (visitado[v.first] == NAOVISITADO)
				dfs(v.first);
		}
}

int main(int argc, char const *argv[])
{
	cin >> V;
	int u, v;
	while (cin >> u >> v){  //no caso de grafo ORIENTADO, duplicar a aresta
		AdjList[u-1].push_back(ii(v-1,0));
		AdjList[v-1].push_back(ii(u-1,0));
	}

	printAdjList(V);

	visitado.assign(V, NAOVISITADO);

	dfs(0);

	return 0;
}



