#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

#define INF 1000000

typedef pair<int, int> ii; // vertice v e peso
typedef vector<ii> vii;
typedef vector<int> vi;

vector<vii> AdjList(200);

int V;
int A;

vi dist;


void printAdjList(int V){
	for (int u = 0; u < V; ++u) { // para todos os vertices...
		printf("%d: ", u+1);
		// para todo v adj a u
		for (int i = 0; i < AdjList[u].size(); ++i){
			ii v = AdjList[u][i];
			printf("(%d,%d) -> ", v.first+1, v.second);
		}
		printf("\n");
	}
}


void bfs(int s){
	queue<int> q;

	q.push(s);
	dist[s] = 0; // distancia de u para u eh zero !!!

	while (!q.empty()){
		int u = q.front(); q.pop();

		printf("%d ", u+1);

		// para todo v adj a u
		for (int i = 0; i < AdjList[u].size(); ++i){
			ii v = AdjList[u][i];
			if (dist[v.first] == INF){
				dist[v.first] = dist[u] + 1;
				q.push(v.first);
			}
		}
	}

}

int main(int argc, char const *argv[])
{
	cin >> V;
	int u, v;
	while (cin >> u >> v){  //no caso de grafo ORIENTADO, duplicar a aresta
		AdjList[u-1].push_back(ii(v-1,0));
		AdjList[v-1].push_back(ii(u-1,0));
	}

	printAdjList(V);

	dist.assign(V, INF);

	bfs(0);

	return 0;
}



