#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;


typedef pair<int, int> ii; // vertice v e peso
typedef vector<ii> vii;
typedef vector<int> vi;

vector<vii> AdjList(200);

int V;
int A;

priority_queue<ii> pq;  // o peso e o vertice...

vi visitado;

void printAdjList(int V){
	for (int u = 0; u < V; ++u) { // para todos os vertices...
		printf("%d: ", u);
		// para todo v adj a u
		for (int i = 0; i < AdjList[u].size(); ++i){
			ii v = AdjList[u][i];
			printf("(%d,%d) -> ", v.first, v.second);
		}
		printf("\n");
	}
}


void process(int u){
	visitado[u] = 1;

	// para todo adjacente v de u
	// para todo v adj a u
	for (int i = 0; i < AdjList[u].size(); ++i){
		ii elem = AdjList[u][i];
		int v = elem.first;
		int peso = elem.second;

		if (visitado[v] == 0){  // se nao foi visitado, coloca na fila.
			pq.push(ii(-peso,-v));
		}
	}

}


int prim(int u){

	visitado.assign(V,0); // nigguem visitado

	process(u); // consulta os adjacente v de u e coloca na fila se nao visitados..

	int custo = 0;

	while (!pq.empty()){
		ii elem = pq.top(); pq.pop(); // retira o top da fila...
		int u = -elem.second;
		int peso = -elem.first;
		if (visitado[u] == 0) {
			custo += peso;
			process(u);
		}

	}

	return custo;
}



int main(int argc, char const *argv[])
{
	cin >> V;
	cin >> A; 
	int u, v, peso;

	for (int i = 0; i < A; ++i) {
		cin >> u >> v >> peso;
		AdjList[u].push_back(ii(v,peso));
		AdjList[v].push_back(ii(u,peso));
	}
	
	printAdjList(V);

	u = 4;

	printf("o valor da MST eh %d\n", prim(u));


	return 0;
}
