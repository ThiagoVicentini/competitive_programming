#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>

#include "UnionFind.h"

using namespace std;


typedef pair<int, int> ii; // vertice v e peso
typedef vector<ii> vii;
typedef vector<int> vi;

vector<vii> AdjList(200);

int V;
int A;

vector< pair<int, ii> > listaArestas; // <peso, <u,v> >


int kruskal(){

	int custo = 0;
	// ordena o vetor de arestas....
	sort(listaArestas.begin(), listaArestas.end());

	UnionFind uf(V);

	// percorra a lista de arestas....
	for (int i = 0; i < listaArestas.size(); ++i){
		pair<int, ii> elem = listaArestas[i];
		int peso = elem.first;
		int u = elem.second.first;
		int v = elem.second.second;

		if (!uf.isSameSet(u, v)){
			custo += peso;
			uf.unionSet(u, v);
		}

	}

	return custo;

}


int main(int argc, char const *argv[])
{
	cin >> V;
	cin >> A; 
	int u, v, peso;

	for (int i = 0; i < A; ++i) {
		cin >> u >> v >> peso;
		listaArestas.push_back(make_pair(peso, ii(u,v)));
	}
	

	printf("o valor da MST eh %d\n", kruskal());


	return 0;
}


